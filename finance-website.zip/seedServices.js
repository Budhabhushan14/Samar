const mongoose = require("mongoose");
const Service = require("./backend/models/Service");

mongoose.connect("mongodb://127.0.0.1:27017/financeApp", {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const services = [
  { name: "Axis Bank Credit Card", description: "Apply for Axis Bank Credit Card with exciting rewards." },
  { name: "Kotak 811 Account", description: "Zero balance account with Kotak 811 digital banking." },
  { name: "HDFC Credit Card", description: "HDFC Bank Credit Cards with travel and shopping benefits." },
  { name: "Demat Account", description: "Open a Demat account for stock trading and investments." },
  { name: "Personal Loan", description: "Get instant personal loans with low interest rates." },
  { name: "EMI Card", description: "Shop now and pay later with easy EMI cards." },
  { name: "ITR Filing", description: "File your Income Tax Returns online quickly and securely." }
];

async function seed() {
  await Service.deleteMany({});
  await Service.insertMany(services);
  console.log("✅ Services seeded!");
  mongoose.connection.close();
}

seed();
